#include "Agent.h"

//Function that returns name
string Agent::getName()
{
    return name;
}

//Function that set's the agents key to true
void Agent::setkey()
{
    key = true;
}
