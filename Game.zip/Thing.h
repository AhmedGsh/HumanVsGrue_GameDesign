#ifndef THING_H
#define THING_H

// hold objects, key, horns and lock
class Thing
{
    public:
    bool key;
    bool lock;
    bool horns;
};
#endif // THING_H
