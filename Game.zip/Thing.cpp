#include "Thing.h"

Thing::Thing()
{
    //ctor
}

Thing::~Thing()
{
    //dtor
}
